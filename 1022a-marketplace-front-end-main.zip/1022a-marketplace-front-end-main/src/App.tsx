import { useEffect, useState } from 'react';
import { Link } from "react-router-dom";
import './App.css'

// Tipo para jogos
type JogoType = {
  codigojg: number,
  nome: string,
  preco: number,
  informacaojg: string,
  imagem: string
}

function App() {
  const [jogos, setJogos] = useState<JogoType[]>([])
  const [mensagem, setMensagem] = useState<string | null>(null)

  // useEffect para carregar produtos e usuários
  useEffect(() => {
    // Buscar os produtos
    fetch("https://one022a-marketplace-actm.onrender.com/jogos")
      .then(resposta => resposta.json())
      .then(dados => setJogos(dados))
  }, [])

  // Função para exibir mensagem ao comprar jogo
  const handleComprar = (jogoNome: string) => {
    setMensagem(`Jogo "${jogoNome}" comprado com sucesso!`);
    setTimeout(() => setMensagem(null), 3000); // Limpa a mensagem após 3 segundos
  }

  return (
    <>
      <header className="site-header">
        <div className="logo">
          <span>GameZone</span>
        </div>
        <nav className="navigation">
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#Store">Store</a></li>
            <li>
              <Link to="/cadastro-jogos">Cadastro Jogos</Link>
            </li>
            <li><a href="#sobre">Categorias</a></li>
            <li><a href="#contato">Support</a></li>
          </ul>
        </nav>

        <div className="header-actions">
          <button className="login-button">Login</button>
        </div>
      </header>

      {/* Seção de Banners */}
      <div className="banners-container">
        <div className="banner-item">
          <img src="https://cdn2.unrealengine.com/Diesel%2Fproductv2%2Flego-batman%2FEGS_WB_LEGO_Batman_G1_1920x1080_19_0911-1920x1080-e166b698acbbbcdae1ff306198684d143828467c.jpg" alt="Banner LEGO Batman" />
        </div>
        <div className="banner-item">
          <img src="https://assets.nintendo.com/image/upload/c_fill,w_1200/q_auto:best/f_auto/dpr_2.0/ncom/software/switch/70010000000964/a28a81253e919298beab2295e39a56b7a5140ef15abdb56135655e5c221b2a3a" alt="Banner Nintendo Switch" />
        </div>
        <div className="banner-item">
          <img src="https://cdn1.epicgames.com/b30b6d1b4dfd4dcc93b5490be5e094e5/offer/RDR2476298253_Epic_Games_Wishlist_RDR2_2560x1440_V01-2560x1440-2a9ebe1f7ee202102555be202d5632ec.jpg" alt="Banner Red Dead Redemption 2" />
        </div>
      </div>

      {/* Mensagem de compra */}
      {mensagem && <div className="mensagem-compra">{mensagem}</div>}

      {/* Listagem de Produtos */}
      <div className="jogos-container">
        <h1 className='jogo-produto'>Os Melhores Jogos Você Encontra Aqui</h1>
        <div className="jogos-list">
          {
            jogos.map(jogo => (
              <div key={jogo.codigojg} className="jogo-item">
                <h3 className="jogo-nome">{jogo.nome}</h3>
                <div className='container-imagem'>
                  <img src={jogo.imagem} alt="Imagem do jogo" />
                </div>
                <p className="jogo-descricao">{jogo.informacaojg}</p>
                
                {/* Valor abaixo da descrição */}
                <p className="jogo-preco">R$ {jogo.preco}</p>

                <button 
                  className="botao-comprar" 
                  onClick={() => handleComprar(jogo.nome)}
                >
                  Comprar
                </button>

                {/* Estrelas abaixo do botão de compra */}
                <div className="estrelas">
                  <span>⭐⭐⭐⭐⭐</span>
                </div>
              </div>
            ))
          }
        </div>
      </div>

      {/* Rodapé */}
      <footer>
        <p>&copy; 2024 GameZone. Todos os direitos reservados.</p>
        <p>
          <a href="#termos">Termos de Serviço</a> | 
          <a href="#privacidade">Política de Privacidade</a>
        </p>
      </footer>
    </>
  )
}

export default App;
